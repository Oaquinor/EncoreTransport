EncoreTransport visual review captures

Screenshots are browser captures from the local checkout after the 2026-10-24 redesign adjustments. Each surface is captured at widths 390, 768, 1024, 1440, and 1920 pixels. Driver and Admin are protected and therefore show Login without an authenticated session. The local Laravel API was unavailable during visual capture; API-dependent empty/error states are visible and no production trip/GPS data is represented.
